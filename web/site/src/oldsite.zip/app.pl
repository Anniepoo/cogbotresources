:- module(app, [
	start/0,
	start_and_wait/0,
	notice/0
]).

%
%  This code after Raivo Laanemet's blog
%

:- use_module(library(http/thread_httpd)).
:- use_module(library(http/http_dispatch)).
:- use_module(library(http/html_write)).
:- use_module(library(http/http_path)).
:- use_module(library(http/http_mime_plugin)).
:- use_module(library(http/http_json)).
:- use_module(library(http/http_server_files)).

% Todo decide what we're really using here
:- use_module(config).   % config constants
:- use_module(logger).   % the logger, obviously
:- use_module(layout).

/*
:- use_module(front).
:- use_module(stat).
:- use_module(post).

:- use_module(files).
:- use_module(tags).
:- use_module(admin).
:- use_module(comment).
:- use_module(db).
*/

:- dynamic started/0.

% http://www.swi-prolog.org/howto/http/HTTPFile.html

% an image is /static/fluffybunny.png, not /static/img/fluffybunny.png
%
http:location(files_uri, '/static', []).
user:file_search_path(document_root, './files').
% static file handlers. js, images, etc. served from ./files
:- http_handler(root(f), serve_files_in_directory(document_root), [prefix]).

% TODO handle the bare domain and requests for index.html
:- http_handler('/index.html' , view(front:handle_front), []).   % TODO need this
:- http_handler(root(.) , view(front:handle_front), []).

start:-
	started,!,
	logger(banner, 'Already running\n', []).

start:-
	logger(banner, 'Starting Cogbot website\n', []),
	server_port(Port),
	http_server(http_dispatch, [port(Port)]),
	assert(started).

start_and_wait:-
	start,
	thread_get_message(_).

notice:-
	writeln('NOTICE:'),
	writeln('To start the server, type: start.'),
	writeln('To reload changed code files, type: make.'),
	site_title(Title),
	server_port(Port),
	db_file(DbFile),
	admin_passwd(ApFile),
	format('Site Name: ~w~n', [Title]),
	format('Server port: ~w~n', [Port]),
	format('Database file: ~w~n', [DbFile]),
	format('Administrator password file: ~w~n', [ApFile]).

% an abstraction of the handler.
% +Callback  - handler for the specific content of this page
% +Request   - the request object
view(Callback, Request):-
	debug(app, 'Calling ~w~n', [Callback]),
	call(Callback, Response, Request),
	reply_view(Response, Request).

%
% output the reply HTML given some direction
% reply_view(+Data, +Request)
%
% possibilities for Data
% html(Title, name_of_content_rule)
%
reply_view(html(Title, ContentRule), _):-
        !,
	phrase(html_layout(Title, ContentRule), Html),
	format('Content-type: text/html~n~n'),
	print_html(Html).

reply_view(html(ContentRule), _):-
	!,
	phrase(ContentRule, Html),
	format('Content-type: text/html~n~n'),
	print_html(Html).

reply_view(redirect(Path), Request):-
	!,
	http_redirect(see_other, Path, Request).

reply_view(json(Json), _):-
	!,
	reply_json(Json).


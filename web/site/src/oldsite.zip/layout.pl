:- module(layout, [
	html_layout//2
]).

:- use_module(library(http/html_write)).

/*
:- use_module(magic).
:- use_module(sidebar).
:- use_module(shjs).
*/

%% <module> General blog page layout.

html_layout(Title, Child) -->
	html([\['<!DOCTYPE html>\n'], html([
		\html_head(Title),
		body([
			div(class = container, [
						p('this is a para')
				div(class = header, \embed_post(header)),
				div(class = content, \Child),
				div(class = sidebar, \html_sidebar),
				div(class = footer, \embed_post(footer))
			])
		])
	])]).

html_head(Title) -->
	html(head([
		meta(charset = 'UTF-8'),
		title(Title),
		link([
			rel = stylesheet,
			type = 'text/css',
			href = location_by_id(style)
		]),
		link([
			rel = stylesheet,
			type = 'text/css',
			href = location_by_id(shjs_css)
		]),
		script(src = location_by_id(modernizr), []),
		script(src = location_by_id(jquery), [])
	])).

html_menu -->
	html([
		a(href = location_by_id(front), 'Front page'),
		' | ', a(href = location_by_id(admin), 'Administration')
	]).

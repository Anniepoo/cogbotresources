:- module(config, [
	server_port/1,
	db_file/1,
	site_title/1,
	admin_passwd/1,
	date_format/1
]).

server_port(12000).
db_file('cogbotsite.db').
site_title('Cogbot').

% Password *file* for admin interface.

admin_passwd('passwd').

% Date format. See documentation of format_time/3.

date_format('%F').

